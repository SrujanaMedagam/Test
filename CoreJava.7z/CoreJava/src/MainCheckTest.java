
public class MainCheckTest {
	public static void main(String args[]){
		String str[]={"srujana","keerti"};
		MainCheckTest m=new MainCheckTest();
		//m.main(str);
	}

}
