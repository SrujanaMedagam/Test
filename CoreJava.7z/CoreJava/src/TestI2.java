
public interface TestI2 {
	public void add();

}
