
public class Test1 extends Test{
	 Test1(){
		System.out.println("Test1");
		
	}
	public static void test123(){
		System.out.println("test123 from Test1");
		
	}
	public static  void test123(int x){
		System.out.println("test123 from Test1 int");
		
	}
	public static void test123(float y){
		System.out.println("test123 from Test1 float");
		
	}

	
	

}
