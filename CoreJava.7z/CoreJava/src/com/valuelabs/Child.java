package com.valuelabs;
public class Child {
	 Dog m1(){
		System.out.println("Child m1()");
		return null;
	}
	public static void main(String[] args){
		Child c = new Child();
		c.m1();
	}

}