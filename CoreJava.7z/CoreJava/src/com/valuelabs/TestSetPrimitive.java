package com.valuelabs;

import java.util.HashSet;
import java.util.Set;

public class TestSetPrimitive {
	public static void main(String args[]){
		HashSet s = new HashSet();
		s.add("2");	
		s.add("2");
		System.out.println(s.size());
	}
	

}
