package com.valuelabs.Interface.Absratact;

 interface TestInterface {
	
}
