package com.valuelabs.Interface.Absratact;

abstract class TestAbstract {
	 TestAbstract(){
		System.out.println("TestAbstract constructor");
	}
	
	 abstract void test();

	}

