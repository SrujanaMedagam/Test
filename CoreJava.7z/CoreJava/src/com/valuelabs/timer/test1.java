package com.valuelabs.timer;

public class test1 {
	static{
		System.out.println("static1 from test1");
	}
	static{
		System.out.println("static2 from test1");
	}
{
		
		System.out.println("instatnt1");
	}
}
