package com.valuelabs.array;

public class SingletonClassUse {

	public static void main(String[] args) {
		System.out.println(SinglrtonClass .getSinglrtonClass());;
		System.out.println(SinglrtonClass .getSinglrtonClass());;
	}

}
