package com.valuelabs;

public class Test123456 extends Test123 {
	public  Test123456(){
		super();
		System.out.println("Test123456 constructor");
	}

	public static void main(String[] args) {
		Test123456 t=new Test123456();
		t.test();

	}

}
