package com.valuelabs;

public class Test123 {
	Test123(){
		System.out.println("Test123 constructor");
	}
protected void test(){
	System.out.println("protected method");
}
}
