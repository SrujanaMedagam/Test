package com.valuelabs;

 class Test {
	public static void main(String[] args){
		System.out.println("hello World");
	}
}
 public class Sample{
	public static void main(String[] args){
		System.out.println("hello Srujana");
	}
}
class Demo{
	public static void main(String[] args){
		System.out.println("hello Sahasra");
	}
}
