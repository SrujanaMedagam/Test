package com.valuelabs;

public class Dog extends Animal{

}
