package com.valuelabs;

public class Demo1 {
	static{
		System.out.println("static block from demo1");
	}

}
