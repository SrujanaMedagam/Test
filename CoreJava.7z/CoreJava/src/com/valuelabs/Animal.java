package com.valuelabs;

public class Animal {

}
