package com.valuelabs;

public class TestInterfaceImplTest {
	public static void main(String args[]){
		TestInterface ti;
	}

}
