package com.valuelabs.comparator;

import java.util.Comparator;

class Test implements Comparator{
	public int compare(Object o1, Object o2) {
		
		return 0;
	}
}