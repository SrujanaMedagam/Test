package com.valuelabs;

abstract public class TestAbsract {
	public String str="Srujana";
	public TestAbsract(){
		System.out.println("TestAbsract constractor");
	}
	abstract void test()  ;
	
	public void set(){
		System.out.println("test method");
	}
	
}
 