package com.valuelabs;

public interface TestInterface {
	void test();
	void test2();
	

}
