package com.valuelabs.Exception;

public class BigAgeException extends Exception{
	BigAgeException(String str){
		super(str);
	}

}
