package com.valuelabs.Exception;

public class SmallAgeException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8825379318523859769L;
	SmallAgeException(){
		
	}
	SmallAgeException(String str){
		super(str);
	}
}
