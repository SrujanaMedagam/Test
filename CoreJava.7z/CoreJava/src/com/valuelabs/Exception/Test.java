package com.valuelabs.Exception;

public class Test {
public void get()throws Exception{
	System.out.println("get method from Test class");
}

}
