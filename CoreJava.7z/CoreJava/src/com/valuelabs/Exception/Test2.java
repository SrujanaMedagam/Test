package com.valuelabs.Exception;

public class Test2 extends Test {
	public void get() throws ArithmeticException{
		System.out.println("get for test2");
	}
	public void get1()throws Exception{
		System.out.println("get method from Test class");
	}

}
