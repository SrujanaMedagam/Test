package com.valuelabs;

public class A {
 A(int a){
	System.out.println("From constructor A with parameters");
}
 A(){
		System.out.println("From constructor A without parameters");
	}
{
	System.out.println("From instance block from A");
}
}
