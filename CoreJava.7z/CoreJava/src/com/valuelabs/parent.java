package com.valuelabs;

public class parent {
	 Animal m1(){
		System.out.println("parent m1()");
		return null;
	}

}

