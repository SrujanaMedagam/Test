package com.valuelabs.strings;

public class StringIndex {
	public static void main(String args[]) {
		String str = "Srujana";
	for (int i = 0; i < str.length(); i++) {
			if ((str.charAt(i) == 'a')) {
				System.out.println(i);
			}

		}
		}

}
