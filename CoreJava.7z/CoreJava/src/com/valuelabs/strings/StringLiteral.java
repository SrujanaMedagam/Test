package com.valuelabs.strings;

public class StringLiteral {
	public static void main(String args[]){
		String s1="Srujana1";
		String s2=new String("Srujana");
		String s3="Srujana";
		String s4="Srujana";
		String s5="Srujana";
		System.out.println(s2==s3);
		System.out.println(s2.equals(s3));
	}

}
