package com.valuelabs.strings;

public class TestSample {
	private TestSample(){
		System.out.println("hjfb");
	}

	

}
