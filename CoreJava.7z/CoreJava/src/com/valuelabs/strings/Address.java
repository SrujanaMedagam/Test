package com.valuelabs.strings;

public class Address {
	String state;
	public Address(String state){
		this.state=state;
	}

	public String getState() {
		return state;
	}

}
