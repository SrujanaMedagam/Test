package com.valuelabs.strings;

public class StringClass {
	public static void main(String args[]){
		String str1=new String("Srujana");
		String str2="Srujana";
		String str3="Srujana";
		System.out.println(str3.equals(str2));
		System.out.println(str3==str2);
	}
	

}
