package com.valuelabs.threads;

public interface Test2 {
	public void get();

}
