package com.valuelabs.threads;
class Address{  
 String addressLine,city,state;  
 public Address(String addressLine, String city, String state) {  
  this.addressLine=addressLine;  
  this.city=city;  
  this.state=state;  
 }  
}  