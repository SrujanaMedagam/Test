package com.valuelabs.threads;

public interface Test3 extends Test1,Test2{
	void get();

}
