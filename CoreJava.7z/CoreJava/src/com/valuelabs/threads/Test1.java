package com.valuelabs.threads;

public interface Test1 {
	public void get();

}
