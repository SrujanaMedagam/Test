package com.valuelabs;

public class Overloading {
	void add(){
		System.out.println("empl=ty");
	}
	void add(int x){
		System.out.println("one");
	}

}
