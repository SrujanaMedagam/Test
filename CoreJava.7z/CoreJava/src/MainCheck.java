
 class MainCheck {
	
	  public static void main(String fghfhfg[]){
		System.out.println("Hello World");
		main(fghfhfg);
		MainCheck m = new MainCheck();
		m.main(fghfhfg);
	}
	
	
	
	

}
