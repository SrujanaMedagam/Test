import java.util.HashMap;

public class ImmutableTest {

	public static void main(String[] args) {
		HashMap map=new HashMap();
		map.put("1", "anu");
		//ImmutableClassTest it = new ImmutableClassTest("1","Srujana",map);
	}

}
