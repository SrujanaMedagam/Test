
public interface TestI {
	public void add();

}
