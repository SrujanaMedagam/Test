
public class Test3 {
	public static void main(String[] args) {
		Test1 t=new Test1();
		t.test123();
		t.test123(2f);

	}

}
