
public class Test {
	public void get(){
		System.out.println("test");
	}
	public static void main(String args[]){
		
		Test t = null;
		t.get();
		
	}

}
